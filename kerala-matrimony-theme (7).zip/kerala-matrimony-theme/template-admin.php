<?php /* Template Name: Admin Panel */ ?>
<?php get_header(); ?>
<main class="admin-page" style="min-height:60vh;">
    <h1>Admin Panel</h1>
    <!-- Admin content will go here -->
</main>
<?php get_footer(); ?> 