<?php /* Template Name: View Other Profile */ ?>
<?php get_header(); ?>
<main class="view-profile-page" style="min-height:60vh;">
    <h1>View Profile</h1>
    <!-- Other profile content will go here -->
</main>
<?php get_footer(); ?> 