<?php /* Template Name: Matches */ ?>
<?php get_header(); ?>
<main class="matches-page" style="min-height:60vh;">
    <h1>Matches</h1>
    <!-- Matches content will go here -->
</main>
<?php get_footer(); ?> 